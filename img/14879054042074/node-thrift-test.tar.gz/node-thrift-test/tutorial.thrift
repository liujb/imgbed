namespace js tutorial

service Calculator {
  void ping(),
  i32 add(1:i32 num1, 2:i32 num2),
  oneway void zip()
}